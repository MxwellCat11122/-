import './NoteItem.less'
import { useState } from 'react'

const NoteItem = ({ note, deleteNote, editNote}) => {
    const [isEditing, setIsEditing] = useState(false)
    const [newContent , setNewContent] = useState(note.content)

    const handleEdit = () => {
        editNote(note.id, { content: newContent })
        setIsEditing(false)
    }
    return(
        <li style={{ backgroundColor: note.color}}>
            {isEditing ? (
                <div>
                    <textarea
                        type="text"
                        value={newContent}
                        onChange={(e) => setNewContent(e.target.value)}
                        />
                        <div className='buttons'>
                            <button onClick={handleEdit} className='save'>Сохранить</button>
                        </div>
                </div>
            ): (
                <div>
                    <span>{note.content}</span>
                    <div className='buttons'>
                        <button onClick={() => setIsEditing(true)} className='edit'>Редактировать</button>
                        <button onClick={() => deleteNote(note.id)} className='del'>Удалить</button>
                    </div>
                </div>
            )}
        </li>
    )
}

export default NoteItem