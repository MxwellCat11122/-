import React from "react";
import './Button.less';

const button = ({children, className, ...props}) => {
    return (
        <button {...props} className={className}>{children}</button>
    )
}

export default button;