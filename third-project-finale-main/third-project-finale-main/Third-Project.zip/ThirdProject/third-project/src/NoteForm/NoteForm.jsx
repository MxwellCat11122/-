import './NoteForm.less';
import { useState } from  "react"

const NoteForm = ({ addNote }) => {
    const [content, setContent] = useState('')
    const [color, setColor] = useState('#ffffff')

    const handleClick = (e) => {
        e.preventDefault()
        if (!content) return

    addNote({
        id: Date.now(),
        content,
        color
    })

    setContent('')
}


    return(
        <form>
            <input
                type="text"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder='Введите заметку'
                />
                <input 
                    type='color'
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                />
                <button onClick={handleClick} className='add'>Добавить заметку</button>
        </form>
    )
}

export default NoteForm