import { useEffect, useState } from 'react'
import './App.css'
import NoteForm from './NoteForm/NoteForm'
import NoteItem from './NoteItem/NoteItem'

function App() {
  const [notes, setNotes] = useState(() => {
    const storeNotes = localStorage.getItem('notes')
    return storeNotes ? JSON.parse(storeNotes) : []
  })

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes)) 
  }, [notes])

  const addNote = (note) => {
  setNotes([
    ...notes,
    {
      ...note,
      color: note.color || getRandomColor()
    }
  ])
}



  const deleteNote = (id) => {
    setNotes(notes.filter((note) => note.id !== id))
  }

 const editNote = (id, updateNote) => {
  setNotes(
    notes.map((note) =>
      note.id === id ? { ...note, ...updateNote } : note
    )
  )
}
  const getRandomColor = () => {
  const colors = [
    '#1aff4c',
    '#00e5ff',
    '#ff9100',
    '#ff4d6d',
    '#a855f7',
    '#22d3ee'
  ]

  return colors[Math.floor(Math.random() * colors.length)]
}



  return (
  <>
    <div className="header">
      <NoteForm addNote={addNote} />
      <h1>Заметки</h1>
    </div>

    <ul className="notes">
      {notes.map((note) => (
        <NoteItem
          key={note.id}
          note={note}
          deleteNote={deleteNote}
          editNote={editNote}
        />
      ))}
    </ul>
  </>
  )
}

export default App
